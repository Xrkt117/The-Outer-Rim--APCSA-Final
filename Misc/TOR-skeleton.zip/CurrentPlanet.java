// CurrentPlanet placeholder (empty shell)
public class CurrentPlanet extends Planet {
    private boolean startingPlanet;

    public CurrentPlanet(String name) {
        super(name);
        this.startingPlanet = true;
    }

    public boolean isStartingPlanet() {
        // to be implemented
        return startingPlanet;
    }

    public void generateMarket() {
        // to be implemented
    }
}
