public class TheOuterRimGame {
    private Player player;
    private Planet currentPlanet;
    private Planet[] planets;

    public TheOuterRimGame() {
        this.planets = new Planet[0];
    }

    public void setupGame() {
        // to be implemented
    }

    public void gameLoop() {
        // to be implemented
    }

    public void displayMenu() {
        // to be implemented
    }

    public void handleChoice(int choice) {
        // to be implemented
    }

    public void travelToPlanet(Planet planet) {
        // to be implemented
    }

    public void buyItem(Item item, int quantity) {
        // to be implemented
    }

    public void sellItem(Item item, int quantity) {
        // to be implemented
    }

    public static void main(String[] args) {
        // to be implemented
    }
}
