// Food item (empty shell)
public class Food extends Item {
    private boolean perishable;

    public Food(int quantity) {
        super("Food", 15, quantity, "Basic food supplies.");
        this.perishable = true;
    }

    public boolean isPerishable() {
        // to be implemented
        return perishable;
    }
}
