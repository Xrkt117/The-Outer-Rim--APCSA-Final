// Medicine item (empty shell)
public class Medicine extends Item {
    private int healingValue;

    public Medicine(int quantity) {
        super("Medicine", 25, quantity, "Medical supplies for colonies.");
        this.healingValue = 1;
    }

    public int getHealingValue() {
        // to be implemented
        return healingValue;
    }
}
