// ScoutShip subclass (empty shell)
public class ScoutShip extends Ship {
    private String description;

    public ScoutShip() {
        super("Scout Ship", 100, 100, 40, 2);
        this.description = "A ship with better fuel range.";
    }

    public String getDescription() {
        // to be implemented
        return description;
    }
}
