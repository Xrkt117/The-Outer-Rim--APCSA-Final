public class Player {
    private String name;
    private int credits;
    private int reputation;
    private Ship ship;

    public Player(String name, Ship ship) {
        this.name = name;
        this.ship = ship;
        this.credits = 100;
        this.reputation = 0;
    }

    public String getName() {
        return name;
    }

    public int getCredits() {
        return credits;
    }

    public int getReputation() {
        return reputation;
    }

    public Ship getShip() {
        return ship;
    }

    public void addCredits(int amount) {
        // to be implemented
    }

    public boolean spendCredits(int amount) {
        // to be implemented
        return false;
    }

    public void addReputation(int amount) {
        // to be implemented
    }
}
