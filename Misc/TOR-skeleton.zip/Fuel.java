// Fuel item (empty shell)
public class Fuel extends Item {
    private int fuelAmount;

    public Fuel(int quantity) {
        super("Fuel", 5, quantity, "Fuel for traveling between planets.");
        this.fuelAmount = 10;
    }

    public int getFuelAmount() {
        // to be implemented
        return fuelAmount;
    }
}
