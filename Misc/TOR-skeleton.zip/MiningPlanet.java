// MiningPlanet (empty shell)
public class MiningPlanet extends Planet {
    private String resourceType;

    public MiningPlanet(String name) {
        super(name);
        this.resourceType = "Ore";
    }

    public String getResourceType() {
        // to be implemented
        return resourceType;
    }

    public void generateMarket() {
        // to be implemented
    }
}
