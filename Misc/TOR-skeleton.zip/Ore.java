// Ore item (empty shell)
public class Ore extends Item {
    private String mineralType;

    public Ore(int quantity) {
        super("Ore", 20, quantity, "Raw minerals and natural resources.");
        this.mineralType = "Ore";
    }

    public String getMineralType() {
        // to be implemented
        return mineralType;
    }
}
