// TradePlanet (empty shell)
public class TradePlanet extends Planet {
    private int tradeTax;

    public TradePlanet(String name) {
        super(name);
        this.tradeTax = 0;
    }

    public int getTradeTax() {
        // to be implemented
        return tradeTax;
    }

    public void generateMarket() {
        // to be implemented
    }
}
