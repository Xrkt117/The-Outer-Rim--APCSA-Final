import java.util.ArrayList;

// Abstract Ship class
public abstract class Ship {
    private String name;
    private int fuel;
    private int maxFuel;
    private int cargoCapacity;
    private ArrayList<Item> cargo;
    private int speed;

    public Ship(String name, int fuel, int maxFuel, int cargoCapacity, int speed) {
        this.name = name;
        this.fuel = fuel;
        this.maxFuel = maxFuel;
        this.cargoCapacity = cargoCapacity;
        this.speed = speed;
        this.cargo = new ArrayList<Item>();
    }

    public String getName() {
        return name;
    }

    public int getFuel() {
        return fuel;
    }

    public void useFuel(int amount) {
        // to be implemented
    }

    public void refuel(int amount) {
        // to be implemented
    }

    public int getSpeed() {
        return speed;
    }

    public int getCargoCapacity() {
        return cargoCapacity;
    }

    public ArrayList<Item> getCargo() {
        return cargo;
    }

    public boolean addItem(Item item) {
        // to be implemented
        return false;
    }

    public boolean removeItem(Item item) {
        // to be implemented
        return false;
    }

}
