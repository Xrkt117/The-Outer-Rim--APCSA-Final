import java.util.ArrayList;

// Abstract Planet class
public abstract class Planet {
    private String name;
    private ArrayList<Item> market;

    public Planet(String name) {
        this.name = name;
        this.market = new ArrayList<Item>();
    }

    public String getName() {
        return name;
    }

    public ArrayList<Item> getMarket() {
        return market;
    }

    public void addMarketItem(Item item) {
        // to be implemented
    }

    public abstract void generateMarket();
}
