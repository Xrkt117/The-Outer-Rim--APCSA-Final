// Abstract Item class (empty shell)
public abstract class Item {
    private String name;
    private int basePrice;
    private int quantity;
    private String description;

    public Item(String name, int price, int quantity, String description) {
        this.name = name;
        this.basePrice = price;
        this.quantity = quantity;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public int getBasePrice() {
        return basePrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getDescription() {
        return description;
    }

    public void setQuantity(int quantity) {
        // to be implemented
    }

}
