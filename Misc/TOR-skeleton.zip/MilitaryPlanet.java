// MilitaryPlanet (empty shell)
public class MilitaryPlanet extends Planet {
    private int securityLevel;

    public MilitaryPlanet(String name) {
        super(name);
        this.securityLevel = 1;
    }

    public int getSecurityLevel() {
        // to be implemented
        return securityLevel;
    }

    public void generateMarket() {
        // to be implemented
    }
}
