// ShipParts item (empty shell)
public class ShipParts extends Item {
    private String partType;

    public ShipParts(int quantity) {
        super("Ship Parts", 50, quantity, "Parts used to repair or upgrade ships.");
        this.partType = "General";
    }

    public String getPartType() {
        // to be implemented
        return partType;
    }
}
