// Market wrapper (empty shell)
public class Market {
    private Item[] items;

    public Market() {
        this.items = new Item[0];
    }

    public Item[] getItems() {
        return items;
    }

    public void addItem(Item item) {
        // to be implemented
    }

    public void displayMarket() {
        // to be implemented
    }
}
