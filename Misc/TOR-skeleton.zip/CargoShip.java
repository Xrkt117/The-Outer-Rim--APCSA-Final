// CargoShip subclass (empty shell)
public class CargoShip extends Ship {
    private String description;

    public CargoShip() {
        super("Cargo Ship", 50, 50, 100, 1);
        this.description = "A ship with high cargo space.";
    }

    public String getDescription() {
        // to be implemented
        return description;
    }
}
